import React from "react";
import Prof from "../components/Prof";
//import Header from "../components/Header";

export default class Home extends React.Component {
  render() {
    return (
      <>
        <Prof />
        
        
      </>
    );
  }
}