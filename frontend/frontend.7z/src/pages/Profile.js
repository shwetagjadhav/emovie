import React from "react";
import Prof from "../components/Prof";
// import Header from "../components/Header";
import Footer from "../components/Footer";

export default class Booking extends React.Component {
    render() {
      return (
        <>
        
         {/* <Header isMoviePage={true}/> */}
         <Prof />        
        <Footer />  
        </>
      );
    }
  }