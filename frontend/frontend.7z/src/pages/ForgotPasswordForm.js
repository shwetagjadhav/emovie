import React from "react";
import ForgotPassword from "../components/ForgotPassword";

export default class Home extends React.Component {
  render() {
    return (
      <>
        <ForgotPassword />
        
        
      </>
    );
  }
}