import React from "react";
import Welcome from "../components/Welcome";
//import Header from "../components/Header";
 
export default class Home extends React.Component {
  render() {
    return (
      <>
        <Welcome />
       
       
      </>
    );
  }
}