import React from "react";
import SignUp from "../components/SignUp";
//import Header from "../components/Header";

export default class Home extends React.Component {
  render() {
    return (
      <>
        <SignUp />
        
        
      </>
    );
  }
}