import React from "react";
import Login from "../components/Login";
//import Header from "../components/Header";

export default class Home extends React.Component {
  render() {
    return (
      <>
        <Login />
        
        
      </>
    );
  }
}